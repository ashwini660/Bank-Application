package com.fullstack.controller;

import java.util.Scanner;

import com.fullstack.model.Customer;
import com.fullstack.service.CustomerService;

public class CustomerController {

	public static void main(String[] args) {

		CustomerService customerService = new CustomerService();

		Customer customer = new Customer(12345, "FULLSTACK");

		Scanner scanner = new Scanner(System.in);

		boolean flag;
		do {
			System.out.println("\n Please enter acc no & password: ");

			long custAccountNumber = scanner.nextLong();

			String custPassword = scanner.next();

			if (customer.getCustomerAccountNumber() == custAccountNumber
					&& customer.getCustomerPassword().equals(custPassword)) {
				System.out.println("\n Welcome to Indian Bank");
				flag = false;
			} else {
				System.out.println("Oops Invalid Credentials Please try again!!!!!");
				flag = true;
			}

		} while (flag);

		do {
			System.out.println("\n Please enter your choice: \n 1. Deposit \n 2. Withdraw \n 3. Transfer \n 4. Logout");

			int ch = scanner.nextInt();

			switch (ch) {
			case 1: // Deposit
				customerService.deposit();

				break;

			case 2: // Withdraw
				customerService.withdraw();

				break;

			case 3: // Transfer
				customerService.transfer();

				break;

			case 4: // Logout
				customerService.logOut();

				break;

			default:
				System.out.println("Invalid Choice");
				break;
			}

		} while (true);

	}

}
