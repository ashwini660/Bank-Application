package com.fullstack.controller;

public class OTPGenerator {

	public static void main(String[] args) {

		for (int i = 1; i <= 1000; i++) {
			System.out.println((int) (Math.random() * 9000 + 1000));
		}
	}

}
