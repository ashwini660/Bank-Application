package com.fullstack.controller;

public class ResearchEx {

	public static void main(String[] args) {

		do {
			//

			System.out.println("Full Stack");
		}

		while (true);
	}

}
