package com.fullstack.model;

public class Customer {

	private long customerAccountNumber;

	private String customerPassword;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(long customerAccountNumber, String customerPassword) {

		this.customerAccountNumber = customerAccountNumber;
		this.customerPassword = customerPassword;
	}

	public long getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(long customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	@Override
	public String toString() {
		return "Customer [customerAccountNumber=" + customerAccountNumber + ", customerPassword=" + customerPassword
				+ "]";
	}

}
