package com.fullstack.service;

import java.util.Scanner;

public class CustomerService {

	double custAccBalance = 10000.00;

	int amount, otp, generatedOTP;

	Scanner scanner = new Scanner(System.in);

	public void deposit() {

		System.out.println("\n Before Deposit Cust Acc Balance: " + custAccBalance);

		System.out.println("\n Please enter amount for deposit: ");

		amount = scanner.nextInt();

		custAccBalance += amount;

		System.out.println("\n After Deposit Cust Acc Balance: " + custAccBalance);

	}

	public void withdraw() {

		System.out.println("\n Before Withdraw Cust Acc Balance: " + custAccBalance);

		System.out.println("\n Please enter amount for Withdraw: ");

		amount = scanner.nextInt();

		if (custAccBalance >= amount) {

			custAccBalance -= amount;

			System.out.println("\n After Withdraw Cust Acc Balance: " + custAccBalance);

		} else {
			System.out.println("Insufficient Fund");
		}

	}

	public void transfer() {

		System.out.println("\n Before Transfer Cust Acc Balance: " + custAccBalance);

		System.out.println("\n Please enter amount for Transfer: ");

		amount = scanner.nextInt();

		if (custAccBalance >= amount) {

			generatedOTP = getOTP();

			System.out.println("\n Please enter OTP: " + generatedOTP);

			otp = scanner.nextInt();

			if (generatedOTP == otp) {

				custAccBalance -= amount;

				System.out.println("\n After Transfer Cust Acc Balance: " + custAccBalance);

			} else {
				System.out.println("Invalid OTP");
			}

		} else {
			System.out.println("Insufficcient Fund");
		}

	}

	public void logOut() {

		System.out.println("\n Customer Logout Successfully");

		System.exit(0);

	}

	int getOTP() {
		return (int) (Math.random() * 9000 + 1000);

	}
}
